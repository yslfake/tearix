
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import { cn } from "@/lib/utils";
import { PenTool, Brain, Image, Download, Users, Menu, HelpCircle, Sparkles } from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";

const MainNavigation = () => {
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path;
  
  // Navigation items array to avoid repetition
  const navItems = [
    { path: '/', label: 'Home', icon: null },
    { path: '/tearix-2d', label: 'Tearix 2D', icon: PenTool },
    { path: '/tearix-3d', label: 'Tearix 3D', icon: Brain },
    { path: '/gallery', label: 'Gallery', icon: Image },
    { path: '/downloads', label: 'Downloads', icon: Download },
    { path: '/team', label: 'Team', icon: Users },
    { path: '/faq', label: 'FAQ', icon: HelpCircle },
  ];

  // Navigation item component to avoid repetition
  const NavItem = ({ path, label, icon: Icon }) => (
    <NavigationMenuItem>
      <Link to={path}>
        <NavigationMenuLink 
          className={cn(
            navigationMenuTriggerStyle(), 
            "flex items-center gap-2",
            isActive(path) && "bg-accent/50"
          )}
        >
          {Icon && <Icon className="w-4 h-4" />}
          <span>{label}</span>
        </NavigationMenuLink>
      </Link>
    </NavigationMenuItem>
  );

  // Mobile navigation item with enhanced styling
  const MobileNavItem = ({ path, label, icon: Icon }) => (
    <Link 
      to={path} 
      className={cn(
        "group flex items-center gap-4 px-6 py-4 text-sm font-medium rounded-xl transition-all duration-300 relative overflow-hidden",
        isActive(path) 
          ? "bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-blue-400 border border-blue-500/30" 
          : "hover:bg-slate-800/80 text-slate-300 hover:text-white border border-transparent hover:border-slate-700/50"
      )}
    >
      {/* Background glow effect */}
      <div className={cn(
        "absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl",
        isActive(path) && "opacity-50"
      )} />
      
      {Icon && (
        <div className={cn(
          "relative z-10 w-8 h-8 rounded-lg flex items-center justify-center transition-all duration-300",
          isActive(path) 
            ? "bg-blue-500/20 text-blue-400" 
            : "bg-slate-700/50 group-hover:bg-slate-600/50 group-hover:scale-110"
        )}>
          <Icon className="w-4 h-4" />
        </div>
      )}
      
      <span className="relative z-10 group-hover:translate-x-1 transition-transform duration-300">
        {label}
      </span>
      
      {isActive(path) && (
        <div className="relative z-10 ml-auto">
          <Sparkles className="w-4 h-4 text-blue-400 animate-pulse" />
        </div>
      )}
    </Link>
  );
  
  return (
    <div className="w-full flex justify-center border-b border-slate-700/50 backdrop-blur-md bg-slate-900/70 fixed top-0 z-40 py-2">
      {/* Desktop Navigation */}
      <div className="hidden md:block">
        <NavigationMenu>
          <NavigationMenuList className="px-4">
            {navItems.map((item) => (
              <NavItem key={item.path} {...item} />
            ))}
          </NavigationMenuList>
        </NavigationMenu>
      </div>
      
      {/* Mobile Navigation */}
      <div className="flex justify-between items-center w-full px-4 md:hidden">
        <Sheet>
          <SheetTrigger asChild>
            <button className="p-3 bg-slate-800/70 text-white hover:bg-slate-800 rounded-lg transition-colors duration-300 group border border-slate-700/50">
              <Menu className="w-6 h-6 group-hover:scale-110 transition-transform duration-300" />
            </button>
          </SheetTrigger>
          <SheetContent 
            side="left" 
            className="w-[280px] bg-slate-900/95 border-slate-700/50 backdrop-blur-xl"
          >
            {/* Header */}
            <div className="px-2 py-6 border-b border-slate-700/50 mb-6">
              <h2 className="text-lg font-semibold text-white mb-1">Navigation</h2>
              <p className="text-sm text-slate-400">Explore Tearix features</p>
            </div>
            
            {/* Navigation Items */}
            <div className="px-2 space-y-2">
              {navItems.map((item) => (
                <MobileNavItem key={item.path} {...item} />
              ))}
            </div>
          </SheetContent>
        </Sheet>

        <Link to="/" className={cn(
          "py-2 px-3 rounded-lg transition-colors duration-300 font-medium",
          isActive('/') ? "text-primary bg-slate-800/50" : "hover:bg-slate-800/50 text-white"
        )}>
          Home
        </Link>
      </div>
    </div>
  );
};

export default MainNavigation;
