
import React from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

type FAQItem = {
  question: string;
  answer: string;
};

interface FAQSectionProps {
  title?: string;
  faqs: FAQItem[];
}

const FAQSection = ({ title = "Frequently Asked Questions", faqs }: FAQSectionProps) => {
  return (
    <div className="w-full max-w-4xl mx-auto py-10 px-4">
      {title && <h2 className="text-3xl font-bold text-center mb-8 bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">{title}</h2>}
      <Accordion type="single" collapsible className="w-full">
        {faqs.map((faq, index) => (
          <AccordionItem 
            key={index} 
            value={`item-${index}`} 
            className="border-slate-700/50 bg-slate-800/30 rounded-lg mb-4 px-6"
          >
            <AccordionTrigger className="text-left font-medium text-white hover:text-cyan-400 transition-colors">
              {faq.question}
            </AccordionTrigger>
            <AccordionContent className="text-slate-300 leading-relaxed">
              <p>{faq.answer}</p>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
};

export default FAQSection;
