
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Bell, BellOff, Smartphone } from 'lucide-react';
import { notificationService } from '@/services/notificationService';
import { useToast } from '@/hooks/use-toast';

const NotificationSubscription = () => {
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkNotificationSupport();
    checkSubscriptionStatus();
  }, []);

  const checkNotificationSupport = async () => {
    const supported = await notificationService.initialize();
    setIsSupported(supported);
  };

  const checkSubscriptionStatus = () => {
    const subscription = notificationService.getStoredSubscription();
    setIsSubscribed(!!subscription);
  };

  const handleSubscribe = async () => {
    setIsLoading(true);
    
    try {
      // Request permission first
      const permissionGranted = await notificationService.requestPermission();
      
      if (!permissionGranted) {
        toast({
          title: "Permission Denied",
          description: "Please enable notifications in your browser settings to receive updates.",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      // Subscribe to notifications
      const subscription = await notificationService.subscribeToNotifications();
      
      if (subscription) {
        setIsSubscribed(true);
        toast({
          title: "Notifications Enabled!",
          description: "You'll receive push notifications when new beta releases are available.",
        });
      } else {
        toast({
          title: "Subscription Failed",
          description: "Failed to enable notifications. Please try again.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Subscription error:', error);
      toast({
        title: "Error",
        description: "An error occurred while setting up notifications.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUnsubscribe = async () => {
    setIsLoading(true);
    
    try {
      const success = await notificationService.unsubscribe();
      
      if (success) {
        setIsSubscribed(false);
        toast({
          title: "Notifications Disabled",
          description: "You will no longer receive push notifications.",
        });
      }
    } catch (error) {
      console.error('Unsubscribe error:', error);
      toast({
        title: "Error",
        description: "Failed to disable notifications.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (!isSupported) {
    return (
      <Card className="p-6 bg-slate-800/50 border-slate-700/50">
        <div className="flex items-center mb-4">
          <Smartphone className="w-6 h-6 text-slate-400 mr-3" />
          <h3 className="text-lg font-medium text-slate-300">Mobile Notifications</h3>
        </div>
        <p className="text-sm text-slate-400 mb-4">
          Push notifications are not supported in this browser. Try using Chrome, Firefox, or Safari on your mobile device.
        </p>
        <Badge variant="outline" className="border-slate-600 text-slate-400">
          Not Supported
        </Badge>
      </Card>
    );
  }

  return (
    <Card className="p-6 bg-slate-800/50 border-slate-700/50">
      <div className="flex items-center mb-4">
        <Smartphone className="w-6 h-6 text-cyan-400 mr-3" />
        <h3 className="text-lg font-medium text-white">Mobile Push Notifications</h3>
        {isSubscribed && (
          <Badge className="ml-auto bg-green-500/10 border-green-400/30 text-green-300">
            Active
          </Badge>
        )}
      </div>
      
      <p className="text-sm text-slate-300 mb-6">
        Get instant notifications on your phone when new beta releases are available for download.
      </p>
      
      <div className="space-y-4">
        {!isSubscribed ? (
          <Button 
            onClick={handleSubscribe}
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
          >
            <Bell className="mr-2 h-4 w-4" />
            {isLoading ? 'Setting up...' : 'Enable Push Notifications'}
          </Button>
        ) : (
          <Button 
            onClick={handleUnsubscribe}
            disabled={isLoading}
            variant="outline"
            className="w-full border-red-400/30 hover:bg-red-500/20 text-red-300"
          >
            <BellOff className="mr-2 h-4 w-4" />
            {isLoading ? 'Disabling...' : 'Disable Notifications'}
          </Button>
        )}
        
        <div className="text-xs text-slate-400">
          <p>• Works on Android and iOS devices</p>
          <p>• Requires browser permission</p>
          <p>• Can be disabled anytime</p>
        </div>
      </div>
    </Card>
  );
};

export default NotificationSubscription;
