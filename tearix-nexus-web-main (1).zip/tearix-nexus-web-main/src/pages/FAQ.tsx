
import React from 'react';
import MainNavigation from '@/components/MainNavigation';
import FAQSection from '@/components/FAQSection';

const FAQ = () => {
  // App-wide FAQs
  const appFAQs = [
    {
      question: "What is Tearix 2D?",
      answer: "Tearix is a powerful creative suite which allow users to create 2d animations or digital arts way faster and supports multiple AI features to make the work easier"
    },
    {
      question: "How do I get started with Tearix?",
      answer: "Download the appropriate version for your device from our Downloads page and follow the installation guide. We also have beginner tutorials available."
    },
    {
      question: "Is Tearix free to use?",
      answer: "Yes Tearix 2D and Tearix both will be Free"
    },
    {
      question: "What is Tearix 2D?",
      answer: "Tearix is a powerful creative suite which allow users to create 2d animations or digital arts way faster and supports multiple AI features to make the work easier."
    },




  ];

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <MainNavigation />
      <div className="container mx-auto pt-20 px-4">
        <h1 className="text-4xl md:text-5xl font-bold mt-8 mb-6 text-center bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">Frequently Asked Questions</h1>
        <p className="text-center text-slate-300 mb-10 text-xl">
          Find answers to commonly asked questions about Tearix
        </p>
        
        <FAQSection faqs={appFAQs} title="" />
      </div>
    </div>
  );
};

export default FAQ;
