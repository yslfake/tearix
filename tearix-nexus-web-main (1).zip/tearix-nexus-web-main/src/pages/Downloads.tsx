import React from 'react';
import MainNavigation from '@/components/MainNavigation';
import NotificationSubscription from '@/components/NotificationSubscription';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Download, PenTool, Brain, Clock, Bell } from 'lucide-react';

const Downloads = () => {
  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <MainNavigation />

      <div className="pt-20 px-6 pb-6">
        <div className="max-w-6xl mx-auto">
          {/* Header Section */}
          <div className="mb-10 text-center">
            <div className="inline-block p-4 rounded-full bg-cyan-500/10 mb-6">
              <Download className="w-12 h-12 text-cyan-400" />
            </div>
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-6">
              Downloads
            </h1>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Get access to our AI-powered animation tools for Android. Join the waiting list to be notified when they're available!
            </p>
          </div>

          {/* Push Notification Subscription */}
          <div className="mb-8">
            <NotificationSubscription />
          </div>

          {/* Cards for Tearix 2D and Tearix 3D */}
          <div className="grid md:grid-cols-2 gap-8">
            {/* Tearix 2D Card */}
            <Card className="p-6 bg-gradient-to-br from-slate-800/90 to-slate-900/90 border-cyan-400/20 hover:border-cyan-400/50 transition-all duration-300">
              <div className="flex items-center mb-6">
                <div className="p-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 mr-4">
                  <PenTool className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">Tearix 2D</h2>
                  <Badge className="bg-cyan-500/10 border-cyan-400/30 text-cyan-300">Coming Soon</Badge>
                </div>
              </div>

              <div className="mb-6 space-y-4">
                <p className="text-slate-300">
                  Create stunning 2D animations with AI assistance. Perfect for character animation, motion graphics, and more.
                </p>
                <div className="flex items-center text-cyan-300">
                  <Clock className="w-4 h-4 mr-2" />
                  <span className="text-sm">Est. Release: in July 2025</span>
                </div>
              </div>

              <div className="space-y-4">
                <Button className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700">
                  <Download className="mr-2 h-4 w-4" />
                  Join Early Access
                </Button>
                <Button variant="outline" className="w-full border-cyan-400/30 hover:bg-cyan-500/20 text-cyan-300">
                  <Bell className="mr-2 h-4 w-4" />
                  Get Notified
                </Button>
              </div>
            </Card>

            {/* Tearix 3D Card */}
            <Card className="p-6 bg-gradient-to-br from-slate-800/90 to-slate-900/90 border-purple-400/20 hover:border-purple-400/50 transition-all duration-300">
              <div className="flex items-center mb-6">
                <div className="p-3 rounded-xl bg-gradient-to-r from-purple-500 to-pink-600 mr-4">
                  <Brain className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">Tearix 3D</h2>
                  <Badge className="bg-purple-500/10 border-purple-400/30 text-purple-300">Coming Soon</Badge>
                </div>
              </div>

              <div className="mb-6 space-y-4">
                <p className="text-slate-300">
                  Experience next-level 3D animation on your Android device with AI-powered rigging, motion capture, and pose estimation.
                </p>
                <div className="flex items-center text-purple-300">
                  <Clock className="w-4 h-4 mr-2" />
                  <span className="text-sm">Est. Release: To Be Answered</span>
                </div>
              </div>

              <div className="space-y-4">
                <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700">
                  <Download className="mr-2 h-4 w-4" />
                  Join Early Access
                </Button>
                <Button variant="outline" className="w-full border-purple-400/30 hover:bg-purple-500/20 text-purple-300">
                  <Bell className="mr-2 h-4 w-4" />
                  Get Notified
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Downloads;