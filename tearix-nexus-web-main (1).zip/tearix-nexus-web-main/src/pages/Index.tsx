
import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, Users, Sparkles, PenTool, Brain, Download, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import MainNavigation from '@/components/MainNavigation';

const ParticleBackground = () => {
  const [particles, setParticles] = useState([]);

  useEffect(() => {
    const newParticles = [];
    for (let i = 0; i < 50; i++) {
      newParticles.push({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: Math.random() * 3 + 1,
        speed: Math.random() * 2 + 1,
        opacity: Math.random() * 0.5 + 0.3,
      });
    }
    setParticles(newParticles);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="absolute rounded-full bg-cyan-400/20 animate-pulse"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            width: `${particle.size}px`,
            height: `${particle.size}px`,
            animationDelay: `${particle.id * 0.1}s`,
            animationDuration: `${particle.speed + 2}s`,
          }}
        />
      ))}
    </div>
  );
};

const FloatingShapes = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute top-3/4 right-1/4 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      <div className="absolute top-1/2 left-3/4 w-24 h-24 bg-pink-500/10 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '4s' }} />
    </div>
  );
};

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Parallax Background Layers */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(56,189,248,0.1),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(168,85,247,0.1),transparent_50%)]" />
      
      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-6xl mx-auto">
        <div className="animate-fade-in">
          <h1 className="text-6xl md:text-8xl font-bold bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-6 tracking-tight">
            TEARIX
          </h1>
          <p className="text-xl md:text-2xl text-slate-300 mb-8 max-w-3xl mx-auto leading-relaxed">
            We're not building just apps—we're building the future.
            From animation to editing, from music to storytelling, Tearix empowers creators, dreamers, and developers with powerful, AI-enhanced tools.
          </p>
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <Badge variant="outline" className="bg-cyan-500/10 border-cyan-400/30 text-cyan-300 text-lg px-4 py-2">
              <Sparkles className="w-4 h-4 mr-2" />
              Coming Soon
            </Badge>
            <Badge variant="outline" className="bg-purple-500/10 border-purple-400/30 text-purple-300 text-lg px-4 py-2">
              <Users className="w-4 h-4 mr-2" />
              Join the Community
            </Badge>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-cyan-400/50 rounded-full p-1">
          <div className="w-1 h-3 bg-cyan-400 rounded-full mx-auto animate-pulse" />
        </div>
      </div>
    </section>
  );
};

const AppCard = ({ title, description, icon: Icon, gradient, delay = 0, appPath }) => {
  return (
    <Card className={`group relative overflow-hidden bg-slate-900/50 backdrop-blur-xl border-slate-700/50 hover:border-cyan-400/50 transition-all duration-500 hover:scale-105 hover:shadow-2xl animate-fade-in`} style={{ animationDelay: `${delay}ms` }}>
      {/* Glassmorphism overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      {/* Neon glow effect */}
      <div className={`absolute inset-0 bg-gradient-to-r ${gradient} opacity-0 group-hover:opacity-20 blur-xl transition-all duration-500`} />
      
      <div className="relative p-8">
        <div className="flex items-center mb-6">
          <div className={`p-3 rounded-xl bg-gradient-to-r ${gradient} mr-4`}>
            <Icon className="w-8 h-8 text-white" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-white mb-2">{title}</h3>
            <Badge variant="outline" className="bg-cyan-500/10 border-cyan-400/30 text-cyan-300">
              Coming Soon
            </Badge>
          </div>
        </div>
        
        <p className="text-slate-300 text-lg leading-relaxed mb-6">
          {description}
        </p>
        
        {/* Feature mockup area */}
        <div className="h-48 bg-slate-800/50 rounded-lg border border-slate-700/50 flex items-center justify-center group-hover:border-cyan-400/30 transition-colors duration-300 mb-4">
          <div className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-cyan-400/20 to-purple-400/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
              <Icon className="w-8 h-8 text-cyan-400" />
            </div>
            <p className="text-slate-400 text-sm">Preview Coming Soon</p>
          </div>
        </div>

        <Link to={appPath}>
          <Button className="w-full bg-slate-700 hover:bg-slate-600 text-white border border-slate-600">
            <Download className="mr-2 h-4 w-4" /> 
            Click for More Info
          </Button>
        </Link>
      </div>
    </Card>
  );
};

const AppsSection = () => {
  return (
    <section className="relative py-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-6">
            Our Animation Apps
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Revolutionize your animation workflow with our AI-powered tools designed for Android
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <AppCard
            title="Tearix 2D"
            description="Create stunning 2D animations with AI assistance. Our intuitive tools make it easy to bring your characters to life with smooth motion, smart tweening, and automated in-betweening powered by artificial intelligence."
            icon={PenTool}
            gradient="from-cyan-500 to-blue-600"
            delay={200}
            appPath="/tearix-2d"
          />
          <AppCard
            title="Tearix 3D"
            description="Experience next-level 3D animation on your Android device. Our AI-powered rigging, motion capture, and pose estimation features allow you to create professional 3D animations without the steep learning curve."
            icon={Brain}
            gradient="from-purple-500 to-pink-600"
            delay={400}
            appPath="/tearix-3d"
          />
        </div>
      </div>
    </section>
  );
};

const CommunitySection = () => {
  return (
    <section className="relative py-20 px-6">
      <div className="max-w-4xl mx-auto text-center">
        <div className="animate-fade-in">
          <a href="https://discord.gg/mRYKuKaFgZ"> <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-6">
            Join Our Community
          </h2></a>
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
            Be part of the journey! Connect with fellow gamers, get exclusive updates, and shape the future of Tearix games.
          </p>
          
          <Button
            asChild
            className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white text-lg px-8 py-4 rounded-full transition-all duration-300 hover:scale-105 hover:shadow-xl animate-pulse group"
          >
            <a
              href="https://discord.gg/mRYKuKaFgZ"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3"
            >
              <svg className="w-6 h-6 group-hover:animate-spin" viewBox="0 0 24 24" fill="currentColor">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>
              </svg>
              Join Discord Community
              <ExternalLink className="w-5 h-5" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="relative py-12 px-6 border-t border-slate-700/50">
      <div className="max-w-4xl mx-auto text-center">
        <div className="mb-8">
          <h3 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-4">
            TEARIX
          </h3>
          <p className="text-slate-400">
            Revolutionizing animation on Android with AI-powered tools.
          </p>
        </div>
        
        <div className="border-t border-slate-700/50 pt-8">
          <p className="text-slate-500 text-sm">
            © 2024 Tearix. All rights reserved. Coming Soon to Android.
          </p>
        </div>
      </div>
    </footer>
  );
};

const Index = () => {
  useEffect(() => {
    // Smooth scrolling behavior
    document.documentElement.style.scrollBehavior = 'smooth';
    
    return () => {
      document.documentElement.style.scrollBehavior = 'auto';
    };
  }, []);

  return (
    <div className="min-h-screen bg-slate-900 text-white overflow-x-hidden">
      {/* Background Effects */}
      <ParticleBackground />
      <FloatingShapes />
      
      {/* Navigation */}
      <MainNavigation />
      
      {/* Main Content */}
      <HeroSection />
      <AppsSection />
      <CommunitySection />
      <Footer />
    </div>
  );
};

export default Index;
