
import React from 'react';
import MainNavigation from '@/components/MainNavigation';
import { Card } from '@/components/ui/card';
import { Users } from 'lucide-react';

const Team = () => {
  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <MainNavigation />
      
      <div className="pt-20 px-6 pb-6">
        <div className="max-w-6xl mx-auto">
          <div className="mb-10 text-center">
            <div className="inline-block p-4 rounded-full bg-cyan-500/10 mb-6">
              <Users className="w-12 h-12 text-cyan-400" />
            </div>
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-6">
              Our Team
            </h1>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Meet the passionate team behind Tearix's revolutionary animation tools.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { name: "Teaser!ani", role: "Owner", bg: "from-cyan-500 to-blue-600" },
              { name: "Dead Zone", role: "Lead Developer", bg: "from-purple-500 to-pink-600" },
              { name: "Piggy From Ohio", role: "Senior Developer", bg: "from-cyan-500 to-purple-600" },
              { name: "Himari (Catzuya)", role: "Developer", bg: "from-blue-500 to-purple-600" },
              { name: "Shubhu", role: "UI/UX designer", bg: "from-pink-500 to-red-600" },
              { name: "Planetoide", role: "Server Admin", bg: "from-green-500 to-cyan-600" },
            ].map((member, index) => (
              <Card key={index} className="overflow-hidden bg-slate-800/50 border-slate-700/50 hover:border-cyan-400/30 transition-all duration-300">
                <div className="h-48 bg-gradient-to-br from-slate-700/50 to-slate-800/50 flex items-center justify-center">
                  <div className={`w-24 h-24 rounded-full bg-gradient-to-r ${member.bg} flex items-center justify-center text-2xl font-bold text-white`}>
                    {member.name.split(' ').map(n => n[0]).join('')}
                  </div>
                </div>
                <div className="p-6 text-center">
                  <h3 className="text-xl font-bold text-white mb-1">{member.name}</h3>
                  <p className="text-sm text-cyan-300">{member.role}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Team;
