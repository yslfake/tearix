
import React from 'react';
import MainNavigation from '@/components/MainNavigation';
import { Button } from "@/components/ui/button";
import { Star, Sparkles, Zap, Palette, Camera, Image } from 'lucide-react';

const Gallery = () => {
  const comingSoonFeatures = [
    {
      icon: Camera,
      title: "AI Photography",
      description: "Revolutionary AI-generated photography"
    },
    {
      icon: Palette,
      title: "Digital Art",
      description: "Stunning digital artwork creations"
    },
    {
      icon: Image,
      title: "3D Renders",
      description: "Photorealistic 3D visualizations"
    },
    {
      icon: Sparkles,
      title: "Mixed Media",
      description: "Innovative mixed media compositions"
    },
    {
      icon: Zap,
      title: "Dynamic Graphics",
      description: "Interactive and animated visuals"
    },
    {
      icon: Star,
      title: "Featured Works",
      description: "Curated collection of top creations"
    }
  ];

  return (
    <div className="min-h-screen bg-slate-950 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-950 to-black" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl animate-float" style={{animationDelay: '2s'}} />
      
      <MainNavigation />
      
      <div className="relative z-10 container mx-auto pt-20 px-4">
        {/* Hero Section */}
        <div className="text-center py-20">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-800/50 border border-slate-700/50 mb-6 animate-fade-in">
            <Sparkles className="w-4 h-4 text-blue-400" />
            <span className="text-sm text-slate-300">Gallery Coming Soon</span>
          </div>
          
          <h1 className="text-6xl md:text-7xl font-bold mb-6 animate-fade-in">
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
              Showcase
            </span>
            <br />
            <span className="text-white">In Progress</span>
          </h1>
          
          <p className="text-xl text-slate-400 mb-8 max-w-2xl mx-auto animate-fade-in">
            We're crafting an incredible gallery experience to showcase amazing creations. 
            Get ready for something extraordinary.
          </p>
          
          <Button 
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-3 rounded-full font-medium transition-all duration-300 hover:scale-105 neon-glow animate-fade-in"
          >
            Notify Me When Ready
          </Button>
        </div>

        {/* Coming Soon Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
          {comingSoonFeatures.map((feature, index) => (
            <div 
              key={index} 
              className="group relative p-6 rounded-xl bg-slate-800/30 border border-slate-700/50 backdrop-blur-sm hover:bg-slate-800/50 hover:border-slate-600/50 transition-all duration-300 hover:scale-105 animate-fade-in"
              style={{animationDelay: `${index * 0.1}s`}}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              <div className="relative z-10">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <feature.icon className="w-6 h-6 text-blue-400" />
                </div>
                
                <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-blue-400 transition-colors duration-300">
                  {feature.title}
                </h3>
                
                <p className="text-slate-400 text-sm group-hover:text-slate-300 transition-colors duration-300">
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Progress Indicator */}
        <div className="text-center pb-20">
          <div className="inline-flex items-center gap-4 px-6 py-4 rounded-xl bg-slate-800/30 border border-slate-700/50 backdrop-blur-sm">
            <div className="flex gap-2">
              <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
              <div className="w-2 h-2 rounded-full bg-blue-400/60 animate-pulse" style={{animationDelay: '0.2s'}} />
              <div className="w-2 h-2 rounded-full bg-blue-400/30 animate-pulse" style={{animationDelay: '0.4s'}} />
            </div>
            <span className="text-slate-300 font-medium">Building something amazing...</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Gallery;
