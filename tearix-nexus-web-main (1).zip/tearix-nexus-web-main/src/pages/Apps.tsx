import React from 'react';
import MainNavigation from '@/components/MainNavigation';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PenTool, Download, Star, Brain } from 'lucide-react';

const Apps = () => {
  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <MainNavigation />

      <div className="pt-20 px-6 pb-6">
        <div className="max-w-6xl mx-auto">
          {/* Tearix 2D Section */}
          <div className="mb-10 text-center">
            <div className="inline-block p-4 rounded-full bg-cyan-500/10 mb-6">
              <PenTool className="w-12 h-12 text-cyan-400" />
            </div>
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-4">
              Tearix 2D
            </h1>
            <Badge className="mb-6 text-lg py-1.5 bg-cyan-500/10 border-cyan-400/30 text-cyan-300">Coming Soon</Badge>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Create stunning 2D animations with AI assistance. Our intuitive tools make it easy to bring your characters to life with smooth motion.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <Card className="p-6 bg-slate-800/50 border-slate-700/50">
              <h2 className="text-2xl font-bold text-white mb-4">Key Features</h2>
              <ul className="space-y-3 text-slate-300">
                <li className="flex items-start">
                  <Star className="w-5 h-5 text-cyan-400 mr-2 mt-0.5" />
                  <span>AI-powered automated in-betweening</span>
                </li>
                <li className="flex items-start">
                  <Star className="w-5 h-5 text-cyan-400 mr-2 mt-0.5" />
                  <span>Smart tweening and motion interpolation</span>
                </li>
                <li className="flex items-start">
                  <Star className="w-5 h-5 text-cyan-400 mr-2 mt-0.5" />
                  <span>Intuitive timeline editor</span>
                </li>
                <li className="flex items-start">
                  <Star className="w-5 h-5 text-cyan-400 mr-2 mt-0.5" />
                  <span>Real-time preview rendering</span>
                </li>
                <li className="flex items-start">
                  <Star className="w-5 h-5 text-cyan-400 mr-2 mt-0.5" />
                  <span>Custom character rigging tools</span>
                </li>
              </ul>
            </Card>

            <Card className="p-6 bg-slate-800/50 border-slate-700/50">
              <h2 className="text-2xl font-bold text-white mb-4">Download Information</h2>
              <div className="space-y-4">
                <p className="text-slate-300">
                  Tearix 2D will be available on the Google Play Store soon. Sign up to be notified when it launches.
                </p>
                <div className="flex flex-col gap-4">
                  <div className="p-4 rounded-lg bg-slate-700/50 border border-slate-600/50">
                    <h3 className="text-lg font-medium text-cyan-300 mb-2">Early Access</h3>
                    <p className="text-sm text-slate-400 mb-4">Join our Discord community to get early access to beta releases.</p>
                    <Button className="w-full bg-slate-700 hover:bg-slate-600 text-white border border-slate-600">
                      <Download className="mr-2 h-4 w-4" /> 
                      Click for More Info
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Tearix 3D Section */}
          <div className="mb-10 text-center">
            <div className="inline-block p-4 rounded-full bg-purple-500/10 mb-6">
              <Brain className="w-12 h-12 text-purple-400" />
            </div>
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent mb-4">
              Tearix 3D
            </h1>
            <Badge className="mb-6 text-lg py-1.5 bg-purple-500/10 border-purple-400/30 text-purple-300">Coming Soon</Badge>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Create stunning 3D animations with AI assistance. Our intuitive tools make it easy to bring your characters to life in a three-dimensional space.
            </p>
          </div>

          {/* Add any additional features or download information for Tearix 3D here */}
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <Card className="p-6 bg-slate-800/50 border-slate-700/50">
              <h2 className="text-2xl font-bold text-white mb-4">Key Features</h2>
              <ul className="space-y-3 text-slate-300">
                <li className="flex items-start">
                  <Star className="w-5 h-5 text-purple-400 mr-2 mt-0.5" />
                  <span>AI-assisted 3D modeling</span>
                </li>
                <li className="flex items-start">
                  <Star className="w-5 h-5 text-purple-400 mr-2 mt-0.5" />
                  <span>Real-time rendering and preview</span>
                </li>
                <li className="flex items-start">
                  <Star className="w-5 h-5 text-purple-400 mr-2 mt-0.5" />
                  <span>Advanced rigging and animation tools</span>
                </li>
                <li className="flex items-start">
                  <Star className="w-5 h-5 text-purple-400 mr-2 mt-0.5" />
                  <span>Seamless integration with popular 3D software</span>
                </li>
              </ul>
            </Card>

            <Card className="p-6 bg-slate-800/50 border-slate-700/50">
              <h2 className="text-2xl font-bold text-white mb-4">Download Information</h2>
              <div className="space-y-4">
                <p className="text-slate-300">
                  Tearix 3D will be available on the Google Play Store soon. Sign up to be notified when it launches.
                </p>
                <div className="flex flex-col gap-4">
                  <div className="p-4 rounded-lg bg-slate-700/50 border border-slate-600/50">
                    <h3 className="text-lg font-medium text-purple-300 mb-2">Early Access</h3>
                    <p className="text-sm text-slate-400 mb-4">Join our Discord community to get early access to beta releases.</p>
                    <Button className="w-full bg-slate-700 hover:bg-slate-600 text-white border border-slate-600">
                      <Download className="mr-2 h-4 w-4" /> 
                      Click for More Info
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Apps;
