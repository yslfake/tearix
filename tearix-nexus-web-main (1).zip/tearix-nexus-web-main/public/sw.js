
self.addEventListener('push', function(event) {
  console.log('Push event received:', event);
  
  const options = {
    body: 'New beta release is now available for download!',
    icon: '/favicon.ico',
    badge: '/favicon.ico',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'explore',
        title: 'Download Now',
        icon: '/favicon.ico'
      },
      {
        action: 'close',
        title: 'Close',
        icon: '/favicon.ico'
      }
    ]
  };

  let title = 'Tearix Beta Release';
  let body = 'New beta release available!';

  if (event.data) {
    const payload = event.data.json();
    title = payload.title || title;
    body = payload.body || body;
    if (payload.icon) options.icon = payload.icon;
  }

  options.body = body;

  event.waitUntil(
    self.registration.showNotification(title, options)
  );
});

self.addEventListener('notificationclick', function(event) {
  console.log('Notification click received:', event);
  
  event.notification.close();

  if (event.action === 'explore') {
    event.waitUntil(
      clients.openWindow('/downloads')
    );
  } else if (event.action === 'close') {
    // Just close the notification
    return;
  } else {
    // Default action - open the downloads page
    event.waitUntil(
      clients.openWindow('/downloads')
    );
  }
});
